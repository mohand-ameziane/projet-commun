import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TablsPage } from './tabls';

@NgModule({
  declarations: [
    TablsPage,
  ],
  imports: [
    IonicPageModule.forChild(TablsPage),
  ],
})
export class TablsPageModule {}

import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { RenMotPassePage } from './ren-mot-passe';

@NgModule({
  declarations: [
    RenMotPassePage,
  ],
  imports: [
    IonicPageModule.forChild(RenMotPassePage),
  ],
})
export class RenMotPassePageModule {}

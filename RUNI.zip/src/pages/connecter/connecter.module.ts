import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ConnecterPage } from './connecter';

@NgModule({
  declarations: [
    ConnecterPage,
  ],
  imports: [
    IonicPageModule.forChild(ConnecterPage),
  ],
})
export class ConnecterPageModule {}

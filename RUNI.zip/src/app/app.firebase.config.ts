export const FIREBASE_CONFIG={
    apiKey: "AIzaSyBqjaUWUBxk3Ps8mAOavZZkb9OF5xyuC24",
    authDomain: "ionicapp-8a685.firebaseapp.com",
    databaseURL: "https://ionicapp-8a685.firebaseio.com",
    projectId: "ionicapp-8a685",
    storageBucket: "ionicapp-8a685.appspot.com",
    messagingSenderId: "206871113536"
  };